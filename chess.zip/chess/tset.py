    #import modules here

import pygame

    #define what colours are
black=(0,0,0)
white=(255,255,255)
turquoise=(64,224,208)
    #initalise pygame
pygame.init()
    #set up screen
screen=pygame.display.set_mode((400,400))
    #what the screen is called and backgroud colour
screen.fill(black)
pygame.display.set_caption("Snake!")
    #set a variable for how quick the game runs
clock = pygame.time.Clock()

'''making future references easier
    eval just takes code as a string and runs it
    eg:
    instead of doing print(5+8)
    you can do eval(print(5+8))'''
def key(key):
    return pygame.ket.get_pressed()[eval("pygame.K_"+key)]
    #draw the snake
snake=(50,150,150,50)
    #display.flip shows what has been drawn on the screen eg the snake
while True:
    pygame.draw.rect(screen,turquoise,snake)
    pygame.display.flip()
    clock.tick(60)
