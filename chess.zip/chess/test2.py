names = ['john', 'jane', 'doe']
names.sort()
a, b, c = names()
print(a, b, c)
