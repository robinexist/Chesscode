
class Dog:  
 
    def __init__(self):
        self.nbLegs = 4
 
tomita = Dog()
 
print("This dog has",tomita.nbLegs,"legs")
